This directory contains header files unique to the
S2740VC board using STM32F302K8
